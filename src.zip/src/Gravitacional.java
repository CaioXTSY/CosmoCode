public interface Gravitacional {
    double calcularForcaGravitacional(CorpoCeleste outroCorpo);

}
